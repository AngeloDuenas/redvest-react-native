import React, { useState } from "react";
import { View, Text, Button, FlatList } from "react-native";

const Leaderboard = () => {
  const [users, setUsers] = useState([ //removed repeated Leaderboard variable "sortedUsers" and replaced with "setUsers" variable
    { id: "1", name: "Alice", score: 100 },
     { id: "2", name: "Fred", score: 70 },
    { id: "3", name: "Bob", score: 90 },
    { id: "4", name: "Maggie", score: 95 },
    { id: "5", name: "Charlie", score: 80 },
  ]); //added more users

  const sortLeaderboard = () => {
    const sortedUsers = [...users].sort((a, b) => b.score - a.score);
    //added spread operator in brackets
    //changed sorting logic to sort values high to low rather than compare
    setUsers(sortedUsers);
  };

  return (
    <View>
      <Text>Leaderboard</Text>
      <FlatList
        data={users}
        renderItem={({ item }) => (
          <Text>
            {item.name}: {item.score}
          </Text>
        )}
        keyExtractor={(item) => item.id}
      />
      <Button title="Sort Leaderboard" onPress={sortLeaderboard} />
    </View>
  );
};

export default Leaderboard;
//Main Issues: constant used twice and incorrect sorting function